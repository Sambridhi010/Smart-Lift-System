namespace LiftApplication.Models
{
    /// <summary>Direction the lift is currently travelling.</summary>
    public enum Direction
    {
        None,
        Up,
        Down
    }
}
