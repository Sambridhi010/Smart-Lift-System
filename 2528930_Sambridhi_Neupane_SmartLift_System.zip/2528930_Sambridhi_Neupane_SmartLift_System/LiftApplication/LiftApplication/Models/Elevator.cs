using System;
using System.Collections.Generic;
using LiftApplication.Patterns;

namespace LiftApplication.Models
{
    
    public class Elevator
    {
        public const int BottomFloor = 1;
        public const int TopFloor = 2;

        public const int TicksPerFloor = 57;        
        public const int TicksPerDoorPhase = 17;    
        public const int HoldTicks = 50;            
        public const double TickSeconds = 0.02;

 
        public string Id;                           
        public double Position = 1;                 
        public double DoorOpenness = 0;            
        public int TargetFloor = 1;                 
        public Direction Direction = Direction.None;
        public int HoldCounter = 0;                 
        public bool HelpRequested = false;         
        public List<int> Stops = new List<int>();   

        public ElevatorState State;                 
        public IdleState StateIdle;
        public MovingState StateMoving;
        public DoorsOpeningState StateDoorsOpening;
        public DoorsOpenState StateDoorsOpen;
        public DoorsClosingState StateDoorsClosing;
        public EmergencyStopState StateEmergency;
        public CallHelpState StateHelp;


        private List<IElevatorObserver> observers = new List<IElevatorObserver>();

        public Elevator(string id)
        {
            Id = id;
            StateIdle = new IdleState(this);
            StateMoving = new MovingState(this);
            StateDoorsOpening = new DoorsOpeningState(this);
            StateDoorsOpen = new DoorsOpenState(this);
            StateDoorsClosing = new DoorsClosingState(this);
            StateEmergency = new EmergencyStopState(this);
            StateHelp = new CallHelpState(this);
            State = StateIdle;
        }


        public string Name
        {
            get { return "Elevator " + Id; }
        }

        public int CurrentFloor
        {
            get { return (int)Math.Round(Position); }
        }

        public string StatusText
        {
            get { return State.Name; }
        }

        public string DoorText
        {
            get { return State.DoorText; }
        }

        public string DoorTextByOpenness
        {
            get
            {
                if (DoorOpenness >= 1.0) return "Open";
                if (DoorOpenness > 0) return "Opening";
                return "Closed";
            }
        }

        public bool HasStops
        {
            get { return Stops.Count > 0; }
        }

        public bool AtFloor
        {
            get { return Math.Abs(Position - Math.Round(Position)) < 0.000001; }
        }

        public bool IsEmergency
        {
            get { return State == StateEmergency; }
        }

        public bool IsHelp
        {
            get { return State == StateHelp || HelpRequested; }
        }

        public bool IsAvailable
        {
            get { return !IsEmergency && !IsHelp; }
        }

        public bool IsBusy
        {
            get
            {
                if (State == StateEmergency || State == StateHelp)
                    return AtFloor && DoorOpenness < 1.0;     
                return State != StateIdle || Stops.Count > 0;
            }
        }

        public bool IsServing(int floor)
        {
            if (Stops.Contains(floor)) return true;
            return State == StateMoving && TargetFloor == floor;
        }

        public int PlannedFloor
        {
            get
            {
                if (Stops.Count > 0) return Stops[Stops.Count - 1];
                if (State == StateMoving) return TargetFloor;
                return CurrentFloor;
            }
        }

        public bool OpenDoorsOneStep()
        {
            if (!AtFloor || DoorOpenness >= 1.0) return false;

            DoorOpenness = DoorOpenness + 1.0 / TicksPerDoorPhase;
            if (DoorOpenness >= 1.0)
            {
                DoorOpenness = 1.0;
                return true;
            }
            return false;
        }


        public void Attach(IElevatorObserver observer)
        {
            observers.Add(observer);
        }

        public void Notify(string message)
        {
            foreach (IElevatorObserver observer in observers)
            {
                observer.Update(this, message);
            }
        }

        // ---- STATE PATTERN ----

        public void ChangeState(ElevatorState newState, string message)
        {
            State = newState;
            Notify(message);
        }

        // Called by the form's timer every 20 ms
        public void Tick()
        {
            State.Tick();
            Notify("");
        }

      

        public void RequestFloor(int floor)
        {
            AddStop(floor, "Inside request", true);
        }

        // A call from a floor, given to this elevator by the dispatcher
        public void AcceptOutsideRequest(int floor, double estimatedSeconds)
        {
            AddStop(floor, "Outside request (est. " + estimatedSeconds.ToString("0.0") + " s)", false);
        }

        public void MoveUp()
        {
            int floor = PlannedFloor + 1;
            if (floor > TopFloor)
                Notify("Up ignored: already at top floor");
            else
                AddStop(floor, "Inside request (up)", true);
        }

        public void MoveDown()
        {
            int floor = PlannedFloor - 1;
            if (floor < BottomFloor)
                Notify("Down ignored: already at ground floor");
            else
                AddStop(floor, "Inside request (down)", true);
        }

        public void OpenDoor()
        {
            State.OpenDoor();
            Notify("");
        }

        public void CloseDoor()
        {
            State.CloseDoor();
            Notify("");
        }

        // Back to floor 1 with the doors closed and an empty queue
        public void Reset()
        {
            Stops.Clear();
            Position = BottomFloor;
            TargetFloor = BottomFloor;
            DoorOpenness = 0;
            HoldCounter = 0;
            Direction = Direction.None;
            HelpRequested = false;
            ChangeState(StateIdle, "Reset");
        }

        public void EmergencyStop()
        {
            if (IsEmergency)
            {
                Notify("Emergency stop already active");
                return;
            }
            Stops.Clear();
            Direction = Direction.None;
            HoldCounter = 0;
            HelpRequested = false;
            ChangeState(StateEmergency, "EMERGENCY STOP pressed");
        }

        public void CallHelp()
        {
            if (IsEmergency || IsHelp)
            {
                Notify("Call Help ignored: help or emergency stop already active");
                return;
            }

            if (State == StateMoving)
            {
                HelpRequested = true;
                Notify("HELP REQUESTED: will stop at floor " + TargetFloor);
            }
            else
            {
                Stops.Clear();
                Direction = Direction.None;
                HoldCounter = 0;
                ChangeState(StateHelp, "HELP CALLED at floor " + CurrentFloor);
            }
        }

        public void Resume()
        {
            if (State == StateEmergency || State == StateHelp)
                State.Resume();
            else
                Notify("Resume ignored: no emergency stop or help call active");
            Notify("");
        }

        // ---- adding a floor to the queue ----

        private void AddStop(int floor, string source, bool fromInsidePanel)
        {
            // 1. refuse everything while stopped or waiting for help
            if (!IsAvailable)
            {
                Notify(source + " rejected: emergency stop or help call active");
                return;
            }

            // 2. refuse floors that do not exist
            if (floor < BottomFloor || floor > TopFloor)
            {
                Notify(source + " rejected: invalid floor " + floor);
                return;
            }

            if (IsServing(floor))
            {
                Notify(source + ": floor " + floor + " already queued");
                return;
            }

            bool doorsWorking = State == StateDoorsOpening || State == StateDoorsOpen || State == StateDoorsClosing;
            if (doorsWorking && floor == CurrentFloor)
            {
                Notify(source + ": floor " + floor + " (already here)");
                State.OpenDoor();
                return;
            }

            Stops.Add(floor);
            Notify(source + ": floor " + floor);

            if (fromInsidePanel && (State == StateDoorsOpen || State == StateDoorsOpening))
                State.CloseDoor();
        }

        // ---- dispatcher support ----

        public double EstimateResponseSeconds(int floor)
        {
            if (!IsAvailable) return double.PositiveInfinity;

            int doorCycle = 2 * TicksPerDoorPhase + HoldTicks;    // open + wait + close
            double ticks = 0;
            double pos = Position;

            // 1. finish the current job
            if (State == StateMoving)
            {
                ticks = ticks + Math.Abs(pos - TargetFloor) * TicksPerFloor + doorCycle;
                pos = TargetFloor;
            }
            else if (State != StateIdle)
            {
                ticks = ticks + doorCycle / 2;                    
            }

            foreach (int stop in Stops)
            {
                ticks = ticks + Math.Abs(pos - stop) * TicksPerFloor + doorCycle;
                pos = stop;
            }

            ticks = ticks + Math.Abs(pos - floor) * TicksPerFloor;

            return ticks * TickSeconds;
        }
    }
}
