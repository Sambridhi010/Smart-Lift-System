namespace LiftApplication.Models
{
 
    public delegate void ElevatorAction(Elevator elevator);
}
