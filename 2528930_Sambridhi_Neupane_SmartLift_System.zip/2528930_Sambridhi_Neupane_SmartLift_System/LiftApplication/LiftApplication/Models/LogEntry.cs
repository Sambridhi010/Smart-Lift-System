using System;

namespace LiftApplication.Models
{
    public class LogEntry
    {
        public string ElevatorName { get; set; }
        public string Operation { get; set; }
        public int FloorNumber { get; set; }
        public string State { get; set; }
        public string Direction { get; set; }
        public string DoorStatus { get; set; }
        public DateTime LoggedAt { get; set; }
    }
}
