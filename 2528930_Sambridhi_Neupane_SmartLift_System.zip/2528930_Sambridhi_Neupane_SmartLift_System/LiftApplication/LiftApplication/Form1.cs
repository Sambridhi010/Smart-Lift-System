﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using LiftApplication.Forms;
using LiftApplication.Models;
using LiftApplication.Patterns;
using LiftApplication.Services;

namespace LiftApplication
{
    // The main window. The layout (all the buttons and labels) is in Form1.Designer.cs.
    // This file contains only the button code and the code that updates the screen.
    //
    // Form1 is an OBSERVER: every time an elevator changes, it calls Update() below and the screen is redrawn.
    // Controls of elevator A and elevator B share the same click handlers. Each control has a Tag
    // ("A" or "B") that tells the handler which elevator it belongs to.
    public partial class Form1 : Form, IElevatorObserver
    {
        // Pixel positions used for the animation (they match the designer layout)
        private const int FloorDistance = 285;      // pixels between floor 1 and floor 2
        private const int Floor1CabinY = 435;       // Top of the cabin when the elevator is on floor 1

        // Colours
        private Color navy = Color.FromArgb(22, 40, 77);
        private Color litColor = Color.FromArgb(255, 214, 64);          // button light ON
        private Color idleColor = Color.FromArgb(46, 150, 80);
        private Color busyColor = Color.FromArgb(230, 140, 20);
        private Color helpColor = Color.FromArgb(170, 90, 0);
        private Color emergencyColor = Color.FromArgb(200, 30, 40);

        // The two elevators, the dispatcher and the database objects
        private Elevator elevatorA = new Elevator("A");
        private Elevator elevatorB = new Elevator("B");
        private List<Elevator> elevators = new List<Elevator>();
        private ElevatorDispatcher dispatcher;
        private ElevatorLogRepository repository = new ElevatorLogRepository();
        private DatabaseLogger logger;
        private bool saveErrorShown = false;

        // Controls grouped in arrays. Index 0 = Elevator A, index 1 = Elevator B.
        private Label[] floorDisplays;
        private Label[] statusLabels;
        private Label[] directionLabels;
        private Label[] doorLabels;
        private Label[] queueLabels;
        private Panel[] cabins;
        private Panel[] interiors;
        private Panel[] carDoorsLeft;
        private Panel[] carDoorsRight;
        private Label[] cabinFloors;
        private Button[] floor1Buttons;
        private Button[] floor2Buttons;

        // Controls for the two floors. Index 0 = floor 1, index 1 = floor 2.
        private Label[] floorStatusLabels;
        private Panel[] floorDoorFrames;
        private Panel[] floorDoorsLeft;
        private Panel[] floorDoorsRight;
        private Button[] callButtons;

        // Outside calls that are still waiting. For each floor: which elevator will answer (null = no call).
        private Elevator[] callTargets = new Elevator[2];

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
        }

        // ---------------------------------------------------------------- start up

        private void Form1_Load(object sender, EventArgs e)
        {
            // 1. put the controls into arrays
            floorDisplays = new Label[] { lblFloorDisplayA, lblFloorDisplayB };
            statusLabels = new Label[] { lblStatusA, lblStatusB };
            directionLabels = new Label[] { lblDirectionA, lblDirectionB };
            doorLabels = new Label[] { lblDoorStatusA, lblDoorStatusB };
            queueLabels = new Label[] { lblQueueA, lblQueueB };
            floor1Buttons = new Button[] { btnFloor1A, btnFloor1B };
            floor2Buttons = new Button[] { btnFloor2A, btnFloor2B };
            cabinFloors = new Label[] { lblCabinFloorA, lblCabinFloorB };
            cabins = new Panel[] { pnlLiftCabinA, pnlLiftCabinB };
            interiors = new Panel[] { pnlCabinInteriorA, pnlCabinInteriorB };
            carDoorsLeft = new Panel[] { pnlDoorLeftA, pnlDoorLeftB };
            carDoorsRight = new Panel[] { pnlDoorRightA, pnlDoorRightB };
            floorStatusLabels = new Label[] { lblFloorStatus1, lblFloorStatus2 };
            floorDoorFrames = new Panel[] { pnlDoor1, pnlDoor2 };
            floorDoorsLeft = new Panel[] { pnlFloorDoorLeft1, pnlFloorDoorLeft2 };
            floorDoorsRight = new Panel[] { pnlFloorDoorRight1, pnlFloorDoorRight2 };
            callButtons = new Button[] { btnCallFloor1, btnCallFloor2 };

            // 2. create the dispatcher
            elevators.Add(elevatorA);
            elevators.Add(elevatorB);
            dispatcher = new ElevatorDispatcher(elevators);

            // 3. check that the database file exists (warn the user if not)
            try
            {
                repository.EnsureAvailable();
            }
            catch (LogDatabaseException ex)
            {
                MessageBox.Show(ex.Message, "Smart Lift System", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            // 4. OBSERVER PATTERN: this form and the logger watch both elevators
            logger = new DatabaseLogger(repository);
            logger.SaveFailed += ShowSaveError;
            foreach (Elevator elevator in elevators)
            {
                elevator.Attach(this);
                elevator.Attach(logger);
            }

            // 5. draw everything for the first time
            foreach (Elevator elevator in elevators)
            {
                RefreshElevator(elevator);
            }
            UpdateCallLights();
            RefreshFloors();
        }

        // ------------------------------------------------ OBSERVER: called by the elevators

        public void Update(Elevator elevator, string message)
        {
            RefreshElevator(elevator);
            UpdateCallLights();
            RefreshFloors();

            // the timer only needs to run while an elevator is busy
            tmrLiftMovement.Enabled = elevatorA.IsBusy || elevatorB.IsBusy;
        }

        // ------------------------------------------------ buttons on the elevator panels
        // One handler serves both elevators: GetElevator() reads the control's Tag.

        private void btnFloor2_Click(object sender, EventArgs e) { GetElevator(sender).RequestFloor(2); }
        private void btnFloor1_Click(object sender, EventArgs e) { GetElevator(sender).RequestFloor(1); }
        private void btnUp_Click(object sender, EventArgs e) { GetElevator(sender).MoveUp(); }
        private void btnDown_Click(object sender, EventArgs e) { GetElevator(sender).MoveDown(); }
        private void btnOpenDoor_Click(object sender, EventArgs e) { GetElevator(sender).OpenDoor(); }
        private void btnCloseDoor_Click(object sender, EventArgs e) { GetElevator(sender).CloseDoor(); }
        private void btnReset_Click(object sender, EventArgs e) { GetElevator(sender).Reset(); }
        private void btnEmergency_Click(object sender, EventArgs e) { GetElevator(sender).EmergencyStop(); }
        private void btnCallHelp_Click(object sender, EventArgs e) { GetElevator(sender).CallHelp(); }
        private void btnResume_Click(object sender, EventArgs e) { GetElevator(sender).Resume(); }

        // ------------------------------------------------ buttons in the header

        private void btnEmergencyAll_Click(object sender, EventArgs e)
        {
            ForEachElevator(StopElevator);
        }

        private void btnResetAll_Click(object sender, EventArgs e)
        {
            ForEachElevator(ResetElevator);
            lblDispatchInfo.Text = "Last call: none";
        }

        private void btnShowLog_Click(object sender, EventArgs e)
        {
            try
            {
                LogForm logForm = new LogForm(repository);
                logForm.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show("The log window could not be opened: " + ex.Message, "Smart Lift System",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ------------------------------------------------ Call Lift buttons (one on each floor)

        private void btnCallFloor_Click(object sender, EventArgs e)
        {
            int floor = int.Parse(((Control)sender).Tag.ToString());     // the Tag holds 1 or 2

            // the dispatcher picks the elevator with the shortest estimated response time
            double estimate;
            Elevator chosen = dispatcher.HandleOutsideRequest(floor, out estimate);

            if (chosen == null)
            {
                lblDispatchInfo.Text = "Floor " + floor + " call  \u2192  no elevator available (emergency stop)";
                return;
            }

            callTargets[floor - 1] = chosen;       // the call button's light goes ON
            UpdateCallLights();
            lblDispatchInfo.Text = "Floor " + floor + " call  \u2192  " + chosen.Name +
                                   "  (estimated " + estimate.ToString("0.0") + " s)";
        }

        // ------------------------------------------------ the timer (animation)

        private void tmrLiftMovement_Tick(object sender, EventArgs e)
        {
            // one animation step for every elevator
            ForEachElevator(AnimateElevator);
        }

        // ------------------------------------------------ DELEGATE
        // ElevatorAction is a delegate: it lets us pass a method as a parameter.
        // ForEachElevator runs the method it is given on both elevators.

        private void ForEachElevator(ElevatorAction action)
        {
            foreach (Elevator elevator in elevators)
            {
                action(elevator);
            }
        }

        private void AnimateElevator(Elevator elevator)
        {
            if (elevator.IsBusy) elevator.Tick();
        }

        private void StopElevator(Elevator elevator)
        {
            elevator.EmergencyStop();
        }

        private void ResetElevator(Elevator elevator)
        {
            elevator.Reset();
        }

        // ------------------------------------------------ drawing the screen

        private Elevator GetElevator(object sender)
        {
            Control control = (Control)sender;
            if (control.Tag.ToString() == "A") return elevatorA;
            return elevatorB;
        }

        private int IndexOf(Elevator elevator)
        {
            if (elevator == elevatorA) return 0;
            return 1;
        }

        // Copies one elevator's data onto its own panel
        private void RefreshElevator(Elevator elevator)
        {
            int i = IndexOf(elevator);

            floorDisplays[i].Text = elevator.CurrentFloor.ToString();
            cabinFloors[i].Text = elevator.CurrentFloor.ToString();
            statusLabels[i].Text = "Status: " + elevator.StatusText;
            directionLabels[i].Text = "Direction: " + elevator.Direction;
            doorLabels[i].Text = "Door: " + elevator.DoorText;

            string queue = "-";
            if (elevator.HasStops) queue = string.Join(", ", elevator.Stops);
            queueLabels[i].Text = "Queue: " + queue;

            // the status colour: green = idle, orange = busy, amber = help, red = emergency
            Color color = idleColor;
            if (elevator.IsEmergency) color = emergencyColor;
            else if (elevator.IsHelp) color = helpColor;
            else if (elevator.IsBusy) color = busyColor;
            statusLabels[i].ForeColor = color;

            // the floor buttons light up while that floor is requested
            SetLight(floor1Buttons[i], elevator.IsServing(1), "Floor 1");
            SetLight(floor2Buttons[i], elevator.IsServing(2), "Floor 2");

            // move the cabin up or down inside its shaft
            int offset = (int)Math.Round((elevator.Position - 1) * FloorDistance);
            cabins[i].Top = Floor1CabinY - offset;

            // slide the two car doors
            SlideDoors(carDoorsLeft[i], carDoorsRight[i], interiors[i].Width, interiors[i].Height, elevator.DoorOpenness);
        }

        // Updates the two floor status displays and slides the floor doors
        private void RefreshFloors()
        {
            string text = FloorText(elevatorA) + "\n" + FloorText(elevatorB);

            for (int i = 0; i < 2; i++)
            {
                int floor = i + 1;
                floorStatusLabels[i].Text = text;

                // the floor door opens together with the car door of an elevator standing at this floor
                double open = 0;
                foreach (Elevator elevator in elevators)
                {
                    bool here = elevator.CurrentFloor == floor && elevator.State != elevator.StateMoving;
                    if (here && elevator.DoorOpenness > open) open = elevator.DoorOpenness;
                }
                SlideDoors(floorDoorsLeft[i], floorDoorsRight[i], floorDoorFrames[i].Width, floorDoorFrames[i].Height, open);
            }
        }

        private string FloorText(Elevator elevator)
        {
            if (elevator.IsEmergency) return elevator.Id + ": STOPPED, floor " + elevator.CurrentFloor;
            if (elevator.State == elevator.StateHelp) return elevator.Id + ": HELP, floor " + elevator.CurrentFloor;

            string arrow = "";
            if (elevator.Direction == Direction.Up) arrow = "\u25B2 ";
            if (elevator.Direction == Direction.Down) arrow = "\u25BC ";
            return elevator.Id + ": " + arrow + "Floor " + elevator.CurrentFloor;
        }

        // Moves the two halves of a door apart (openness 0 = closed, 1 = fully open)
        private void SlideDoors(Panel left, Panel right, int width, int height, double openness)
        {
            int doorWidth = (int)Math.Round(width / 2.0 * (1.0 - openness));
            left.SetBounds(0, 0, doorWidth, height);
            right.SetBounds(width - doorWidth, 0, doorWidth, height);
        }

        // A call button's light stays on until the chosen elevator has arrived (or was stopped / reset)
        private void UpdateCallLights()
        {
            for (int i = 0; i < 2; i++)
            {
                int floor = i + 1;
                if (callTargets[i] != null && !callTargets[i].IsServing(floor))
                {
                    callTargets[i] = null;      // the elevator has arrived: light off
                }
                SetLight(callButtons[i], callTargets[i] != null, "Call Lift (Floor " + floor + ")");
            }
        }

        // Turns a button's "light" on or off (yellow = requested)
        private void SetLight(Button button, bool lit, string caption)
        {
            if (lit)
            {
                button.BackColor = litColor;
                button.ForeColor = navy;
                button.UseVisualStyleBackColor = false;
                button.Text = caption + "  *";
            }
            else
            {
                button.UseVisualStyleBackColor = true;
                button.ForeColor = SystemColors.ControlText;
                button.Text = caption;
            }
        }

        // Shows a database error once (not every time)
        private void ShowSaveError(string message)
        {
            if (saveErrorShown) return;
            saveErrorShown = true;
            MessageBox.Show(message, "Smart Lift System - logging problem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
