﻿namespace LiftApplication
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmrLiftMovement = new System.Windows.Forms.Timer(this.components);
            this.pnlBuilding = new System.Windows.Forms.Panel();
            this.lblFloor2 = new System.Windows.Forms.Label();
            this.lblFloorStatus2 = new System.Windows.Forms.Label();
            this.pnlDoor2 = new System.Windows.Forms.Panel();
            this.pnlFloorDoorLeft2 = new System.Windows.Forms.Panel();
            this.pnlFloorDoorRight2 = new System.Windows.Forms.Panel();
            this.lblFloor1 = new System.Windows.Forms.Label();
            this.lblFloorStatus1 = new System.Windows.Forms.Label();
            this.pnlDoor1 = new System.Windows.Forms.Panel();
            this.pnlFloorDoorLeft1 = new System.Windows.Forms.Panel();
            this.pnlFloorDoorRight1 = new System.Windows.Forms.Panel();
            this.pnlFloorDivider = new System.Windows.Forms.Panel();
            this.pnlLiftShaftA = new System.Windows.Forms.Panel();
            this.lblShaftTitleA = new System.Windows.Forms.Label();
            this.pnlLiftCabinA = new System.Windows.Forms.Panel();
            this.lblCabinFloorA = new System.Windows.Forms.Label();
            this.pnlCabinInteriorA = new System.Windows.Forms.Panel();
            this.pnlDoorLeftA = new System.Windows.Forms.Panel();
            this.pnlDoorRightA = new System.Windows.Forms.Panel();
            this.pnlLiftShaftB = new System.Windows.Forms.Panel();
            this.lblShaftTitleB = new System.Windows.Forms.Label();
            this.pnlLiftCabinB = new System.Windows.Forms.Panel();
            this.lblCabinFloorB = new System.Windows.Forms.Label();
            this.pnlCabinInteriorB = new System.Windows.Forms.Panel();
            this.pnlDoorLeftB = new System.Windows.Forms.Panel();
            this.pnlDoorRightB = new System.Windows.Forms.Panel();
            this.btnCallFloor2 = new System.Windows.Forms.Button();
            this.btnCallFloor1 = new System.Windows.Forms.Button();
            this.lblDispatchInfo = new System.Windows.Forms.Label();
            this.btnEmergencyAll = new System.Windows.Forms.Button();
            this.btnResetAll = new System.Windows.Forms.Button();
            this.btnShowLog = new System.Windows.Forms.Button();
            this.grpElevatorA = new System.Windows.Forms.GroupBox();
            this.lblFloorDisplayA = new System.Windows.Forms.Label();
            this.lblStatusA = new System.Windows.Forms.Label();
            this.lblDirectionA = new System.Windows.Forms.Label();
            this.lblDoorStatusA = new System.Windows.Forms.Label();
            this.lblQueueA = new System.Windows.Forms.Label();
            this.btnFloor1A = new System.Windows.Forms.Button();
            this.btnFloor2A = new System.Windows.Forms.Button();
            this.btnUpA = new System.Windows.Forms.Button();
            this.btnDownA = new System.Windows.Forms.Button();
            this.btnOpenDoorA = new System.Windows.Forms.Button();
            this.btnCloseDoorA = new System.Windows.Forms.Button();
            this.btnEmergencyA = new System.Windows.Forms.Button();
            this.btnResumeA = new System.Windows.Forms.Button();
            this.btnResetA = new System.Windows.Forms.Button();
            this.btnCallHelpA = new System.Windows.Forms.Button();
            this.grpElevatorB = new System.Windows.Forms.GroupBox();
            this.lblFloorDisplayB = new System.Windows.Forms.Label();
            this.lblStatusB = new System.Windows.Forms.Label();
            this.lblDirectionB = new System.Windows.Forms.Label();
            this.lblDoorStatusB = new System.Windows.Forms.Label();
            this.lblQueueB = new System.Windows.Forms.Label();
            this.btnFloor1B = new System.Windows.Forms.Button();
            this.btnFloor2B = new System.Windows.Forms.Button();
            this.btnUpB = new System.Windows.Forms.Button();
            this.btnDownB = new System.Windows.Forms.Button();
            this.btnOpenDoorB = new System.Windows.Forms.Button();
            this.btnCloseDoorB = new System.Windows.Forms.Button();
            this.btnEmergencyB = new System.Windows.Forms.Button();
            this.btnResumeB = new System.Windows.Forms.Button();
            this.btnResetB = new System.Windows.Forms.Button();
            this.btnCallHelpB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // pnlBuilding
            this.pnlBuilding.Location = new System.Drawing.Point(0, 0);
            this.pnlBuilding.Size = new System.Drawing.Size(440, 570);
            this.pnlBuilding.BackColor = System.Drawing.Color.FromArgb(226, 230, 238);
            this.pnlBuilding.Name = "pnlBuilding";
            // lblFloor2
            this.lblFloor2.Location = new System.Drawing.Point(15, 20);
            this.lblFloor2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloor2.ForeColor = System.Drawing.Color.White;
            this.lblFloor2.Text = "FLOOR 2\r\n(Top Floor)";
            this.lblFloor2.AutoSize = false;
            this.lblFloor2.Size = new System.Drawing.Size(120, 50);
            this.lblFloor2.BackColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblFloor2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFloor2.Name = "lblFloor2";
            // lblFloorStatus2
            this.lblFloorStatus2.Location = new System.Drawing.Point(15, 108);
            this.lblFloorStatus2.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorStatus2.ForeColor = System.Drawing.Color.White;
            this.lblFloorStatus2.Text = "A: Floor 1\r\nB: Floor 1";
            this.lblFloorStatus2.AutoSize = false;
            this.lblFloorStatus2.Size = new System.Drawing.Size(120, 36);
            this.lblFloorStatus2.BackColor = System.Drawing.Color.FromArgb(15, 25, 50);
            this.lblFloorStatus2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFloorStatus2.Name = "lblFloorStatus2";
            // pnlDoor2
            this.pnlDoor2.Location = new System.Drawing.Point(30, 150);
            this.pnlDoor2.Size = new System.Drawing.Size(80, 134);
            this.pnlDoor2.BackColor = System.Drawing.Color.FromArgb(28, 34, 48);
            this.pnlDoor2.Name = "pnlDoor2";
            // pnlFloorDoorLeft2
            this.pnlFloorDoorLeft2.Location = new System.Drawing.Point(0, 0);
            this.pnlFloorDoorLeft2.Size = new System.Drawing.Size(40, 134);
            this.pnlFloorDoorLeft2.BackColor = System.Drawing.Color.FromArgb(70, 85, 110);
            this.pnlFloorDoorLeft2.Name = "pnlFloorDoorLeft2";
            // pnlFloorDoorRight2
            this.pnlFloorDoorRight2.Location = new System.Drawing.Point(40, 0);
            this.pnlFloorDoorRight2.Size = new System.Drawing.Size(40, 134);
            this.pnlFloorDoorRight2.BackColor = System.Drawing.Color.FromArgb(70, 85, 110);
            this.pnlFloorDoorRight2.Name = "pnlFloorDoorRight2";
            // lblFloor1
            this.lblFloor1.Location = new System.Drawing.Point(15, 305);
            this.lblFloor1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloor1.ForeColor = System.Drawing.Color.White;
            this.lblFloor1.Text = "FLOOR 1\r\n(Ground Floor)";
            this.lblFloor1.AutoSize = false;
            this.lblFloor1.Size = new System.Drawing.Size(120, 50);
            this.lblFloor1.BackColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblFloor1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFloor1.Name = "lblFloor1";
            // lblFloorStatus1
            this.lblFloorStatus1.Location = new System.Drawing.Point(15, 395);
            this.lblFloorStatus1.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorStatus1.ForeColor = System.Drawing.Color.White;
            this.lblFloorStatus1.Text = "A: Floor 1\r\nB: Floor 1";
            this.lblFloorStatus1.AutoSize = false;
            this.lblFloorStatus1.Size = new System.Drawing.Size(120, 36);
            this.lblFloorStatus1.BackColor = System.Drawing.Color.FromArgb(15, 25, 50);
            this.lblFloorStatus1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFloorStatus1.Name = "lblFloorStatus1";
            // pnlDoor1
            this.pnlDoor1.Location = new System.Drawing.Point(30, 435);
            this.pnlDoor1.Size = new System.Drawing.Size(80, 134);
            this.pnlDoor1.BackColor = System.Drawing.Color.FromArgb(28, 34, 48);
            this.pnlDoor1.Name = "pnlDoor1";
            // pnlFloorDoorLeft1
            this.pnlFloorDoorLeft1.Location = new System.Drawing.Point(0, 0);
            this.pnlFloorDoorLeft1.Size = new System.Drawing.Size(40, 134);
            this.pnlFloorDoorLeft1.BackColor = System.Drawing.Color.FromArgb(70, 85, 110);
            this.pnlFloorDoorLeft1.Name = "pnlFloorDoorLeft1";
            // pnlFloorDoorRight1
            this.pnlFloorDoorRight1.Location = new System.Drawing.Point(40, 0);
            this.pnlFloorDoorRight1.Size = new System.Drawing.Size(40, 134);
            this.pnlFloorDoorRight1.BackColor = System.Drawing.Color.FromArgb(70, 85, 110);
            this.pnlFloorDoorRight1.Name = "pnlFloorDoorRight1";
            // pnlFloorDivider
            this.pnlFloorDivider.Location = new System.Drawing.Point(0, 284);
            this.pnlFloorDivider.Size = new System.Drawing.Size(160, 4);
            this.pnlFloorDivider.BackColor = System.Drawing.Color.FromArgb(150, 158, 175);
            this.pnlFloorDivider.Name = "pnlFloorDivider";
            // pnlLiftShaftA
            this.pnlLiftShaftA.Location = new System.Drawing.Point(160, 0);
            this.pnlLiftShaftA.Size = new System.Drawing.Size(130, 570);
            this.pnlLiftShaftA.BackColor = System.Drawing.Color.FromArgb(38, 45, 62);
            this.pnlLiftShaftA.Name = "pnlLiftShaftA";
            // lblShaftTitleA
            this.lblShaftTitleA.Location = new System.Drawing.Point(0, 6);
            this.lblShaftTitleA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShaftTitleA.ForeColor = System.Drawing.Color.White;
            this.lblShaftTitleA.Text = "ELEVATOR A";
            this.lblShaftTitleA.AutoSize = false;
            this.lblShaftTitleA.Size = new System.Drawing.Size(130, 20);
            this.lblShaftTitleA.BackColor = System.Drawing.Color.FromArgb(38, 45, 62);
            this.lblShaftTitleA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShaftTitleA.Name = "lblShaftTitleA";
            // pnlLiftCabinA
            this.pnlLiftCabinA.Location = new System.Drawing.Point(15, 435);
            this.pnlLiftCabinA.Size = new System.Drawing.Size(100, 120);
            this.pnlLiftCabinA.BackColor = System.Drawing.Color.FromArgb(235, 178, 38);
            this.pnlLiftCabinA.Name = "pnlLiftCabinA";
            // lblCabinFloorA
            this.lblCabinFloorA.Location = new System.Drawing.Point(30, 5);
            this.lblCabinFloorA.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCabinFloorA.ForeColor = System.Drawing.Color.FromArgb(255, 200, 60);
            this.lblCabinFloorA.Text = "1";
            this.lblCabinFloorA.AutoSize = false;
            this.lblCabinFloorA.Size = new System.Drawing.Size(40, 20);
            this.lblCabinFloorA.BackColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblCabinFloorA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCabinFloorA.Name = "lblCabinFloorA";
            // pnlCabinInteriorA
            this.pnlCabinInteriorA.Location = new System.Drawing.Point(10, 30);
            this.pnlCabinInteriorA.Size = new System.Drawing.Size(80, 82);
            this.pnlCabinInteriorA.BackColor = System.Drawing.Color.FromArgb(255, 238, 180);
            this.pnlCabinInteriorA.Name = "pnlCabinInteriorA";
            // pnlDoorLeftA
            this.pnlDoorLeftA.Location = new System.Drawing.Point(0, 0);
            this.pnlDoorLeftA.Size = new System.Drawing.Size(40, 82);
            this.pnlDoorLeftA.BackColor = System.Drawing.Color.FromArgb(150, 158, 172);
            this.pnlDoorLeftA.Name = "pnlDoorLeftA";
            // pnlDoorRightA
            this.pnlDoorRightA.Location = new System.Drawing.Point(40, 0);
            this.pnlDoorRightA.Size = new System.Drawing.Size(40, 82);
            this.pnlDoorRightA.BackColor = System.Drawing.Color.FromArgb(150, 158, 172);
            this.pnlDoorRightA.Name = "pnlDoorRightA";
            // pnlLiftShaftB
            this.pnlLiftShaftB.Location = new System.Drawing.Point(305, 0);
            this.pnlLiftShaftB.Size = new System.Drawing.Size(130, 570);
            this.pnlLiftShaftB.BackColor = System.Drawing.Color.FromArgb(38, 45, 62);
            this.pnlLiftShaftB.Name = "pnlLiftShaftB";
            // lblShaftTitleB
            this.lblShaftTitleB.Location = new System.Drawing.Point(0, 6);
            this.lblShaftTitleB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShaftTitleB.ForeColor = System.Drawing.Color.White;
            this.lblShaftTitleB.Text = "ELEVATOR B";
            this.lblShaftTitleB.AutoSize = false;
            this.lblShaftTitleB.Size = new System.Drawing.Size(130, 20);
            this.lblShaftTitleB.BackColor = System.Drawing.Color.FromArgb(38, 45, 62);
            this.lblShaftTitleB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblShaftTitleB.Name = "lblShaftTitleB";
            // pnlLiftCabinB
            this.pnlLiftCabinB.Location = new System.Drawing.Point(15, 435);
            this.pnlLiftCabinB.Size = new System.Drawing.Size(100, 120);
            this.pnlLiftCabinB.BackColor = System.Drawing.Color.FromArgb(235, 178, 38);
            this.pnlLiftCabinB.Name = "pnlLiftCabinB";
            // lblCabinFloorB
            this.lblCabinFloorB.Location = new System.Drawing.Point(30, 5);
            this.lblCabinFloorB.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCabinFloorB.ForeColor = System.Drawing.Color.FromArgb(255, 200, 60);
            this.lblCabinFloorB.Text = "1";
            this.lblCabinFloorB.AutoSize = false;
            this.lblCabinFloorB.Size = new System.Drawing.Size(40, 20);
            this.lblCabinFloorB.BackColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblCabinFloorB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCabinFloorB.Name = "lblCabinFloorB";
            // pnlCabinInteriorB
            this.pnlCabinInteriorB.Location = new System.Drawing.Point(10, 30);
            this.pnlCabinInteriorB.Size = new System.Drawing.Size(80, 82);
            this.pnlCabinInteriorB.BackColor = System.Drawing.Color.FromArgb(255, 238, 180);
            this.pnlCabinInteriorB.Name = "pnlCabinInteriorB";
            // pnlDoorLeftB
            this.pnlDoorLeftB.Location = new System.Drawing.Point(0, 0);
            this.pnlDoorLeftB.Size = new System.Drawing.Size(40, 82);
            this.pnlDoorLeftB.BackColor = System.Drawing.Color.FromArgb(150, 158, 172);
            this.pnlDoorLeftB.Name = "pnlDoorLeftB";
            // pnlDoorRightB
            this.pnlDoorRightB.Location = new System.Drawing.Point(40, 0);
            this.pnlDoorRightB.Size = new System.Drawing.Size(40, 82);
            this.pnlDoorRightB.BackColor = System.Drawing.Color.FromArgb(150, 158, 172);
            this.pnlDoorRightB.Name = "pnlDoorRightB";
            // btnCallFloor2
            this.btnCallFloor2.Name = "btnCallFloor2";
            this.btnCallFloor2.Location = new System.Drawing.Point(15, 76);
            this.btnCallFloor2.Size = new System.Drawing.Size(120, 30);
            this.btnCallFloor2.Text = "Call Lift (Floor 2)";
            this.btnCallFloor2.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallFloor2.Tag = "2";
            this.btnCallFloor2.UseVisualStyleBackColor = true;
            this.btnCallFloor2.Click += new System.EventHandler(this.btnCallFloor_Click);
            // btnCallFloor1
            this.btnCallFloor1.Name = "btnCallFloor1";
            this.btnCallFloor1.Location = new System.Drawing.Point(15, 361);
            this.btnCallFloor1.Size = new System.Drawing.Size(120, 30);
            this.btnCallFloor1.Text = "Call Lift (Floor 1)";
            this.btnCallFloor1.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallFloor1.Tag = "1";
            this.btnCallFloor1.UseVisualStyleBackColor = true;
            this.btnCallFloor1.Click += new System.EventHandler(this.btnCallFloor_Click);
            // lblDispatchInfo
            this.lblDispatchInfo.Name = "lblDispatchInfo";
            this.lblDispatchInfo.Location = new System.Drawing.Point(460, 14);
            this.lblDispatchInfo.AutoSize = true;
            this.lblDispatchInfo.Text = "Last call: none";
            this.lblDispatchInfo.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // btnEmergencyAll
            this.btnEmergencyAll.Name = "btnEmergencyAll";
            this.btnEmergencyAll.Location = new System.Drawing.Point(460, 44);
            this.btnEmergencyAll.Size = new System.Drawing.Size(110, 34);
            this.btnEmergencyAll.Text = "Stop All";
            this.btnEmergencyAll.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmergencyAll.UseVisualStyleBackColor = true;
            this.btnEmergencyAll.Click += new System.EventHandler(this.btnEmergencyAll_Click);
            // btnResetAll
            this.btnResetAll.Name = "btnResetAll";
            this.btnResetAll.Location = new System.Drawing.Point(578, 44);
            this.btnResetAll.Size = new System.Drawing.Size(110, 34);
            this.btnResetAll.Text = "Reset All";
            this.btnResetAll.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetAll.UseVisualStyleBackColor = true;
            this.btnResetAll.Click += new System.EventHandler(this.btnResetAll_Click);
            // btnShowLog
            this.btnShowLog.Name = "btnShowLog";
            this.btnShowLog.Location = new System.Drawing.Point(696, 44);
            this.btnShowLog.Size = new System.Drawing.Size(114, 34);
            this.btnShowLog.Text = "Show Log";
            this.btnShowLog.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowLog.UseVisualStyleBackColor = true;
            this.btnShowLog.Click += new System.EventHandler(this.btnShowLog_Click);
            // grpElevatorA
            this.grpElevatorA.Name = "grpElevatorA";
            this.grpElevatorA.Location = new System.Drawing.Point(460, 94);
            this.grpElevatorA.Size = new System.Drawing.Size(300, 396);
            this.grpElevatorA.Text = "Elevator A";
            this.grpElevatorA.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblFloorDisplayA
            this.lblFloorDisplayA.Name = "lblFloorDisplayA";
            this.lblFloorDisplayA.Location = new System.Drawing.Point(10, 24);
            this.lblFloorDisplayA.Size = new System.Drawing.Size(280, 56);
            this.lblFloorDisplayA.Text = "1";
            this.lblFloorDisplayA.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorDisplayA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // lblStatusA
            this.lblStatusA.Name = "lblStatusA";
            this.lblStatusA.Location = new System.Drawing.Point(16, 86);
            this.lblStatusA.Size = new System.Drawing.Size(270, 20);
            this.lblStatusA.Text = "Status: Idle";
            this.lblStatusA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblDirectionA
            this.lblDirectionA.Name = "lblDirectionA";
            this.lblDirectionA.Location = new System.Drawing.Point(16, 108);
            this.lblDirectionA.Size = new System.Drawing.Size(270, 20);
            this.lblDirectionA.Text = "Direction: None";
            this.lblDirectionA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblDoorStatusA
            this.lblDoorStatusA.Name = "lblDoorStatusA";
            this.lblDoorStatusA.Location = new System.Drawing.Point(16, 130);
            this.lblDoorStatusA.Size = new System.Drawing.Size(270, 20);
            this.lblDoorStatusA.Text = "Door: Closed";
            this.lblDoorStatusA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblQueueA
            this.lblQueueA.Name = "lblQueueA";
            this.lblQueueA.Location = new System.Drawing.Point(16, 152);
            this.lblQueueA.Size = new System.Drawing.Size(270, 20);
            this.lblQueueA.Text = "Queue: -";
            this.lblQueueA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // btnFloor1A
            this.btnFloor1A.Name = "btnFloor1A";
            this.btnFloor1A.Location = new System.Drawing.Point(16, 186);
            this.btnFloor1A.Size = new System.Drawing.Size(130, 34);
            this.btnFloor1A.Text = "Floor 1";
            this.btnFloor1A.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloor1A.Tag = "A";
            this.btnFloor1A.UseVisualStyleBackColor = true;
            this.btnFloor1A.Click += new System.EventHandler(this.btnFloor1_Click);
            // btnFloor2A
            this.btnFloor2A.Name = "btnFloor2A";
            this.btnFloor2A.Location = new System.Drawing.Point(154, 186);
            this.btnFloor2A.Size = new System.Drawing.Size(130, 34);
            this.btnFloor2A.Text = "Floor 2";
            this.btnFloor2A.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloor2A.Tag = "A";
            this.btnFloor2A.UseVisualStyleBackColor = true;
            this.btnFloor2A.Click += new System.EventHandler(this.btnFloor2_Click);
            // btnUpA
            this.btnUpA.Name = "btnUpA";
            this.btnUpA.Location = new System.Drawing.Point(16, 226);
            this.btnUpA.Size = new System.Drawing.Size(130, 34);
            this.btnUpA.Text = "Up";
            this.btnUpA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpA.Tag = "A";
            this.btnUpA.UseVisualStyleBackColor = true;
            this.btnUpA.Click += new System.EventHandler(this.btnUp_Click);
            // btnDownA
            this.btnDownA.Name = "btnDownA";
            this.btnDownA.Location = new System.Drawing.Point(154, 226);
            this.btnDownA.Size = new System.Drawing.Size(130, 34);
            this.btnDownA.Text = "Down";
            this.btnDownA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownA.Tag = "A";
            this.btnDownA.UseVisualStyleBackColor = true;
            this.btnDownA.Click += new System.EventHandler(this.btnDown_Click);
            // btnOpenDoorA
            this.btnOpenDoorA.Name = "btnOpenDoorA";
            this.btnOpenDoorA.Location = new System.Drawing.Point(16, 266);
            this.btnOpenDoorA.Size = new System.Drawing.Size(130, 34);
            this.btnOpenDoorA.Text = "Open Door";
            this.btnOpenDoorA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenDoorA.Tag = "A";
            this.btnOpenDoorA.UseVisualStyleBackColor = true;
            this.btnOpenDoorA.Click += new System.EventHandler(this.btnOpenDoor_Click);
            // btnCloseDoorA
            this.btnCloseDoorA.Name = "btnCloseDoorA";
            this.btnCloseDoorA.Location = new System.Drawing.Point(154, 266);
            this.btnCloseDoorA.Size = new System.Drawing.Size(130, 34);
            this.btnCloseDoorA.Text = "Close Door";
            this.btnCloseDoorA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseDoorA.Tag = "A";
            this.btnCloseDoorA.UseVisualStyleBackColor = true;
            this.btnCloseDoorA.Click += new System.EventHandler(this.btnCloseDoor_Click);
            // btnEmergencyA
            this.btnEmergencyA.Name = "btnEmergencyA";
            this.btnEmergencyA.Location = new System.Drawing.Point(16, 306);
            this.btnEmergencyA.Size = new System.Drawing.Size(130, 34);
            this.btnEmergencyA.Text = "Emergency Stop";
            this.btnEmergencyA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmergencyA.Tag = "A";
            this.btnEmergencyA.UseVisualStyleBackColor = true;
            this.btnEmergencyA.Click += new System.EventHandler(this.btnEmergency_Click);
            // btnResumeA
            this.btnResumeA.Name = "btnResumeA";
            this.btnResumeA.Location = new System.Drawing.Point(154, 306);
            this.btnResumeA.Size = new System.Drawing.Size(130, 34);
            this.btnResumeA.Text = "Resume";
            this.btnResumeA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResumeA.Tag = "A";
            this.btnResumeA.UseVisualStyleBackColor = true;
            this.btnResumeA.Click += new System.EventHandler(this.btnResume_Click);
            // btnResetA
            this.btnResetA.Name = "btnResetA";
            this.btnResetA.Location = new System.Drawing.Point(16, 346);
            this.btnResetA.Size = new System.Drawing.Size(130, 34);
            this.btnResetA.Text = "Reset Lift";
            this.btnResetA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetA.Tag = "A";
            this.btnResetA.UseVisualStyleBackColor = true;
            this.btnResetA.Click += new System.EventHandler(this.btnReset_Click);
            // btnCallHelpA
            this.btnCallHelpA.Name = "btnCallHelpA";
            this.btnCallHelpA.Location = new System.Drawing.Point(154, 346);
            this.btnCallHelpA.Size = new System.Drawing.Size(130, 34);
            this.btnCallHelpA.Text = "Call Help";
            this.btnCallHelpA.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallHelpA.Tag = "A";
            this.btnCallHelpA.UseVisualStyleBackColor = true;
            this.btnCallHelpA.Click += new System.EventHandler(this.btnCallHelp_Click);
            // grpElevatorB
            this.grpElevatorB.Name = "grpElevatorB";
            this.grpElevatorB.Location = new System.Drawing.Point(770, 94);
            this.grpElevatorB.Size = new System.Drawing.Size(300, 396);
            this.grpElevatorB.Text = "Elevator B";
            this.grpElevatorB.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblFloorDisplayB
            this.lblFloorDisplayB.Name = "lblFloorDisplayB";
            this.lblFloorDisplayB.Location = new System.Drawing.Point(10, 24);
            this.lblFloorDisplayB.Size = new System.Drawing.Size(280, 56);
            this.lblFloorDisplayB.Text = "1";
            this.lblFloorDisplayB.Font = new System.Drawing.Font("Segoe UI", 32F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFloorDisplayB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // lblStatusB
            this.lblStatusB.Name = "lblStatusB";
            this.lblStatusB.Location = new System.Drawing.Point(16, 86);
            this.lblStatusB.Size = new System.Drawing.Size(270, 20);
            this.lblStatusB.Text = "Status: Idle";
            this.lblStatusB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblDirectionB
            this.lblDirectionB.Name = "lblDirectionB";
            this.lblDirectionB.Location = new System.Drawing.Point(16, 108);
            this.lblDirectionB.Size = new System.Drawing.Size(270, 20);
            this.lblDirectionB.Text = "Direction: None";
            this.lblDirectionB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblDoorStatusB
            this.lblDoorStatusB.Name = "lblDoorStatusB";
            this.lblDoorStatusB.Location = new System.Drawing.Point(16, 130);
            this.lblDoorStatusB.Size = new System.Drawing.Size(270, 20);
            this.lblDoorStatusB.Text = "Door: Closed";
            this.lblDoorStatusB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // lblQueueB
            this.lblQueueB.Name = "lblQueueB";
            this.lblQueueB.Location = new System.Drawing.Point(16, 152);
            this.lblQueueB.Size = new System.Drawing.Size(270, 20);
            this.lblQueueB.Text = "Queue: -";
            this.lblQueueB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // btnFloor1B
            this.btnFloor1B.Name = "btnFloor1B";
            this.btnFloor1B.Location = new System.Drawing.Point(16, 186);
            this.btnFloor1B.Size = new System.Drawing.Size(130, 34);
            this.btnFloor1B.Text = "Floor 1";
            this.btnFloor1B.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloor1B.Tag = "B";
            this.btnFloor1B.UseVisualStyleBackColor = true;
            this.btnFloor1B.Click += new System.EventHandler(this.btnFloor1_Click);
            // btnFloor2B
            this.btnFloor2B.Name = "btnFloor2B";
            this.btnFloor2B.Location = new System.Drawing.Point(154, 186);
            this.btnFloor2B.Size = new System.Drawing.Size(130, 34);
            this.btnFloor2B.Text = "Floor 2";
            this.btnFloor2B.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFloor2B.Tag = "B";
            this.btnFloor2B.UseVisualStyleBackColor = true;
            this.btnFloor2B.Click += new System.EventHandler(this.btnFloor2_Click);
            // btnUpB
            this.btnUpB.Name = "btnUpB";
            this.btnUpB.Location = new System.Drawing.Point(16, 226);
            this.btnUpB.Size = new System.Drawing.Size(130, 34);
            this.btnUpB.Text = "Up";
            this.btnUpB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpB.Tag = "B";
            this.btnUpB.UseVisualStyleBackColor = true;
            this.btnUpB.Click += new System.EventHandler(this.btnUp_Click);
            // btnDownB
            this.btnDownB.Name = "btnDownB";
            this.btnDownB.Location = new System.Drawing.Point(154, 226);
            this.btnDownB.Size = new System.Drawing.Size(130, 34);
            this.btnDownB.Text = "Down";
            this.btnDownB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownB.Tag = "B";
            this.btnDownB.UseVisualStyleBackColor = true;
            this.btnDownB.Click += new System.EventHandler(this.btnDown_Click);
            // btnOpenDoorB
            this.btnOpenDoorB.Name = "btnOpenDoorB";
            this.btnOpenDoorB.Location = new System.Drawing.Point(16, 266);
            this.btnOpenDoorB.Size = new System.Drawing.Size(130, 34);
            this.btnOpenDoorB.Text = "Open Door";
            this.btnOpenDoorB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOpenDoorB.Tag = "B";
            this.btnOpenDoorB.UseVisualStyleBackColor = true;
            this.btnOpenDoorB.Click += new System.EventHandler(this.btnOpenDoor_Click);
            // btnCloseDoorB
            this.btnCloseDoorB.Name = "btnCloseDoorB";
            this.btnCloseDoorB.Location = new System.Drawing.Point(154, 266);
            this.btnCloseDoorB.Size = new System.Drawing.Size(130, 34);
            this.btnCloseDoorB.Text = "Close Door";
            this.btnCloseDoorB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseDoorB.Tag = "B";
            this.btnCloseDoorB.UseVisualStyleBackColor = true;
            this.btnCloseDoorB.Click += new System.EventHandler(this.btnCloseDoor_Click);
            // btnEmergencyB
            this.btnEmergencyB.Name = "btnEmergencyB";
            this.btnEmergencyB.Location = new System.Drawing.Point(16, 306);
            this.btnEmergencyB.Size = new System.Drawing.Size(130, 34);
            this.btnEmergencyB.Text = "Emergency Stop";
            this.btnEmergencyB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmergencyB.Tag = "B";
            this.btnEmergencyB.UseVisualStyleBackColor = true;
            this.btnEmergencyB.Click += new System.EventHandler(this.btnEmergency_Click);
            // btnResumeB
            this.btnResumeB.Name = "btnResumeB";
            this.btnResumeB.Location = new System.Drawing.Point(154, 306);
            this.btnResumeB.Size = new System.Drawing.Size(130, 34);
            this.btnResumeB.Text = "Resume";
            this.btnResumeB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResumeB.Tag = "B";
            this.btnResumeB.UseVisualStyleBackColor = true;
            this.btnResumeB.Click += new System.EventHandler(this.btnResume_Click);
            // btnResetB
            this.btnResetB.Name = "btnResetB";
            this.btnResetB.Location = new System.Drawing.Point(16, 346);
            this.btnResetB.Size = new System.Drawing.Size(130, 34);
            this.btnResetB.Text = "Reset Lift";
            this.btnResetB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetB.Tag = "B";
            this.btnResetB.UseVisualStyleBackColor = true;
            this.btnResetB.Click += new System.EventHandler(this.btnReset_Click);
            // btnCallHelpB
            this.btnCallHelpB.Name = "btnCallHelpB";
            this.btnCallHelpB.Location = new System.Drawing.Point(154, 346);
            this.btnCallHelpB.Size = new System.Drawing.Size(130, 34);
            this.btnCallHelpB.Text = "Call Help";
            this.btnCallHelpB.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCallHelpB.Tag = "B";
            this.btnCallHelpB.UseVisualStyleBackColor = true;
            this.btnCallHelpB.Click += new System.EventHandler(this.btnCallHelp_Click);
            // tmrLiftMovement
            this.tmrLiftMovement.Interval = 20;
            this.tmrLiftMovement.Tick += new System.EventHandler(this.tmrLiftMovement_Tick);
            this.Controls.Add(this.pnlBuilding);
            this.pnlBuilding.Controls.Add(this.lblFloor2);
            this.pnlBuilding.Controls.Add(this.lblFloorStatus2);
            this.pnlBuilding.Controls.Add(this.pnlDoor2);
            this.pnlDoor2.Controls.Add(this.pnlFloorDoorLeft2);
            this.pnlDoor2.Controls.Add(this.pnlFloorDoorRight2);
            this.pnlBuilding.Controls.Add(this.lblFloor1);
            this.pnlBuilding.Controls.Add(this.lblFloorStatus1);
            this.pnlBuilding.Controls.Add(this.pnlDoor1);
            this.pnlDoor1.Controls.Add(this.pnlFloorDoorLeft1);
            this.pnlDoor1.Controls.Add(this.pnlFloorDoorRight1);
            this.pnlBuilding.Controls.Add(this.pnlFloorDivider);
            this.pnlBuilding.Controls.Add(this.pnlLiftShaftA);
            this.pnlLiftShaftA.Controls.Add(this.lblShaftTitleA);
            this.pnlLiftShaftA.Controls.Add(this.pnlLiftCabinA);
            this.pnlLiftCabinA.Controls.Add(this.lblCabinFloorA);
            this.pnlLiftCabinA.Controls.Add(this.pnlCabinInteriorA);
            this.pnlCabinInteriorA.Controls.Add(this.pnlDoorLeftA);
            this.pnlCabinInteriorA.Controls.Add(this.pnlDoorRightA);
            this.pnlBuilding.Controls.Add(this.pnlLiftShaftB);
            this.pnlLiftShaftB.Controls.Add(this.lblShaftTitleB);
            this.pnlLiftShaftB.Controls.Add(this.pnlLiftCabinB);
            this.pnlLiftCabinB.Controls.Add(this.lblCabinFloorB);
            this.pnlLiftCabinB.Controls.Add(this.pnlCabinInteriorB);
            this.pnlCabinInteriorB.Controls.Add(this.pnlDoorLeftB);
            this.pnlCabinInteriorB.Controls.Add(this.pnlDoorRightB);
            this.pnlBuilding.Controls.Add(this.btnCallFloor2);
            this.pnlBuilding.Controls.Add(this.btnCallFloor1);
            this.Controls.Add(this.lblDispatchInfo);
            this.Controls.Add(this.btnEmergencyAll);
            this.Controls.Add(this.btnResetAll);
            this.Controls.Add(this.btnShowLog);
            this.Controls.Add(this.grpElevatorA);
            this.grpElevatorA.Controls.Add(this.lblFloorDisplayA);
            this.grpElevatorA.Controls.Add(this.lblStatusA);
            this.grpElevatorA.Controls.Add(this.lblDirectionA);
            this.grpElevatorA.Controls.Add(this.lblDoorStatusA);
            this.grpElevatorA.Controls.Add(this.lblQueueA);
            this.grpElevatorA.Controls.Add(this.btnFloor1A);
            this.grpElevatorA.Controls.Add(this.btnFloor2A);
            this.grpElevatorA.Controls.Add(this.btnUpA);
            this.grpElevatorA.Controls.Add(this.btnDownA);
            this.grpElevatorA.Controls.Add(this.btnOpenDoorA);
            this.grpElevatorA.Controls.Add(this.btnCloseDoorA);
            this.grpElevatorA.Controls.Add(this.btnEmergencyA);
            this.grpElevatorA.Controls.Add(this.btnResumeA);
            this.grpElevatorA.Controls.Add(this.btnResetA);
            this.grpElevatorA.Controls.Add(this.btnCallHelpA);
            this.Controls.Add(this.grpElevatorB);
            this.grpElevatorB.Controls.Add(this.lblFloorDisplayB);
            this.grpElevatorB.Controls.Add(this.lblStatusB);
            this.grpElevatorB.Controls.Add(this.lblDirectionB);
            this.grpElevatorB.Controls.Add(this.lblDoorStatusB);
            this.grpElevatorB.Controls.Add(this.lblQueueB);
            this.grpElevatorB.Controls.Add(this.btnFloor1B);
            this.grpElevatorB.Controls.Add(this.btnFloor2B);
            this.grpElevatorB.Controls.Add(this.btnUpB);
            this.grpElevatorB.Controls.Add(this.btnDownB);
            this.grpElevatorB.Controls.Add(this.btnOpenDoorB);
            this.grpElevatorB.Controls.Add(this.btnCloseDoorB);
            this.grpElevatorB.Controls.Add(this.btnEmergencyB);
            this.grpElevatorB.Controls.Add(this.btnResumeB);
            this.grpElevatorB.Controls.Add(this.btnResetB);
            this.grpElevatorB.Controls.Add(this.btnCallHelpB);
            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1080, 570);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Smart Lift System";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel pnlBuilding;
        private System.Windows.Forms.Label lblFloor2;
        private System.Windows.Forms.Label lblFloorStatus2;
        private System.Windows.Forms.Panel pnlDoor2;
        private System.Windows.Forms.Panel pnlFloorDoorLeft2;
        private System.Windows.Forms.Panel pnlFloorDoorRight2;
        private System.Windows.Forms.Label lblFloor1;
        private System.Windows.Forms.Label lblFloorStatus1;
        private System.Windows.Forms.Panel pnlDoor1;
        private System.Windows.Forms.Panel pnlFloorDoorLeft1;
        private System.Windows.Forms.Panel pnlFloorDoorRight1;
        private System.Windows.Forms.Panel pnlFloorDivider;
        private System.Windows.Forms.Panel pnlLiftShaftA;
        private System.Windows.Forms.Label lblShaftTitleA;
        private System.Windows.Forms.Panel pnlLiftCabinA;
        private System.Windows.Forms.Label lblCabinFloorA;
        private System.Windows.Forms.Panel pnlCabinInteriorA;
        private System.Windows.Forms.Panel pnlDoorLeftA;
        private System.Windows.Forms.Panel pnlDoorRightA;
        private System.Windows.Forms.Panel pnlLiftShaftB;
        private System.Windows.Forms.Label lblShaftTitleB;
        private System.Windows.Forms.Panel pnlLiftCabinB;
        private System.Windows.Forms.Label lblCabinFloorB;
        private System.Windows.Forms.Panel pnlCabinInteriorB;
        private System.Windows.Forms.Panel pnlDoorLeftB;
        private System.Windows.Forms.Panel pnlDoorRightB;
        private System.Windows.Forms.Button btnCallFloor2;
        private System.Windows.Forms.Button btnCallFloor1;
        private System.Windows.Forms.Label lblDispatchInfo;
        private System.Windows.Forms.Button btnEmergencyAll;
        private System.Windows.Forms.Button btnResetAll;
        private System.Windows.Forms.Button btnShowLog;
        private System.Windows.Forms.GroupBox grpElevatorA;
        private System.Windows.Forms.Label lblFloorDisplayA;
        private System.Windows.Forms.Label lblStatusA;
        private System.Windows.Forms.Label lblDirectionA;
        private System.Windows.Forms.Label lblDoorStatusA;
        private System.Windows.Forms.Label lblQueueA;
        private System.Windows.Forms.Button btnFloor1A;
        private System.Windows.Forms.Button btnFloor2A;
        private System.Windows.Forms.Button btnUpA;
        private System.Windows.Forms.Button btnDownA;
        private System.Windows.Forms.Button btnOpenDoorA;
        private System.Windows.Forms.Button btnCloseDoorA;
        private System.Windows.Forms.Button btnEmergencyA;
        private System.Windows.Forms.Button btnResumeA;
        private System.Windows.Forms.Button btnResetA;
        private System.Windows.Forms.Button btnCallHelpA;
        private System.Windows.Forms.GroupBox grpElevatorB;
        private System.Windows.Forms.Label lblFloorDisplayB;
        private System.Windows.Forms.Label lblStatusB;
        private System.Windows.Forms.Label lblDirectionB;
        private System.Windows.Forms.Label lblDoorStatusB;
        private System.Windows.Forms.Label lblQueueB;
        private System.Windows.Forms.Button btnFloor1B;
        private System.Windows.Forms.Button btnFloor2B;
        private System.Windows.Forms.Button btnUpB;
        private System.Windows.Forms.Button btnDownB;
        private System.Windows.Forms.Button btnOpenDoorB;
        private System.Windows.Forms.Button btnCloseDoorB;
        private System.Windows.Forms.Button btnEmergencyB;
        private System.Windows.Forms.Button btnResumeB;
        private System.Windows.Forms.Button btnResetB;
        private System.Windows.Forms.Button btnCallHelpB;
        private System.Windows.Forms.Timer tmrLiftMovement;
    }
}
