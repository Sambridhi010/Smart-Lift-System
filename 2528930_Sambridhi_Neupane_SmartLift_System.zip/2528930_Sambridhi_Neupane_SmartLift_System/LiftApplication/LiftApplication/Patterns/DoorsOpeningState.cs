using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public class DoorsOpeningState : ElevatorState
    {
        public DoorsOpeningState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get { return "Doors opening"; }
        }

        public override string DoorText
        {
            get { return "Opening"; }
        }

        public override void Tick()
        {
            elevator.DoorOpenness = elevator.DoorOpenness + 1.0 / Elevator.TicksPerDoorPhase;
            if (elevator.DoorOpenness >= 1.0)
            {
                elevator.DoorOpenness = 1.0;
                elevator.HoldCounter = 0;
                elevator.ChangeState(elevator.StateDoorsOpen, "Doors open");
            }
        }

        public override void CloseDoor()
        {
            elevator.ChangeState(elevator.StateDoorsClosing, "Close door pressed");
        }
    }
}
