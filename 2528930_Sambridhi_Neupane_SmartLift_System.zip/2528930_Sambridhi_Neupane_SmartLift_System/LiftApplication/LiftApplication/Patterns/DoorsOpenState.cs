using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public class DoorsOpenState : ElevatorState
    {
        public DoorsOpenState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get { return "Doors open"; }
        }

        public override string DoorText
        {
            get { return "Open"; }
        }

        public override void Tick()
        {
            elevator.HoldCounter = elevator.HoldCounter + 1;
            if (elevator.HoldCounter >= Elevator.HoldTicks)
            {
                elevator.ChangeState(elevator.StateDoorsClosing, "Doors closing (automatic)");
            }
        }

        public override void OpenDoor()
        {
            elevator.HoldCounter = 0;      
        }

        public override void CloseDoor()
        {
            elevator.ChangeState(elevator.StateDoorsClosing, "Close door pressed");
        }
    }
}
