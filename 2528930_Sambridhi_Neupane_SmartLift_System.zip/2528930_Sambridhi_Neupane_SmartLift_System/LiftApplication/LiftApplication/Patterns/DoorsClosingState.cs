using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public class DoorsClosingState : ElevatorState
    {
        public DoorsClosingState(Elevator elevator) : base(elevator) { }
        public override string Name
        {
            get { return "Doors closing"; }
        }

        public override string DoorText
        {
            get { return "Closing"; }
        }

        public override void Tick()
        {
            elevator.DoorOpenness = elevator.DoorOpenness - 1.0 / Elevator.TicksPerDoorPhase;
            if (elevator.DoorOpenness <= 0.0)
            {
                elevator.DoorOpenness = 0.0;
                elevator.ChangeState(elevator.StateIdle, "Doors closed");
            }
        }

        public override void OpenDoor()
        {
            elevator.ChangeState(elevator.StateDoorsOpening, "Door re-opened");
        }
    }
}
