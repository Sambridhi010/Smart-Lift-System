using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public interface IElevatorObserver
    {
 
        void Update(Elevator elevator, string message);
    }
}
