using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public class MovingState : ElevatorState
    {
        public MovingState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get
            {
                if (elevator.Direction == Direction.Up) return "Moving up";
                return "Moving down";
            }
        }

        public override void Tick()
        {
            // move a small step towards the target floor
            double step = 1.0 / Elevator.TicksPerFloor;
            if (elevator.Direction == Direction.Up)
                elevator.Position = elevator.Position + step;
            else
                elevator.Position = elevator.Position - step;

            // have we arrived?
            bool arrived = false;
            if (elevator.Direction == Direction.Up && elevator.Position >= elevator.TargetFloor) arrived = true;
            if (elevator.Direction == Direction.Down && elevator.Position <= elevator.TargetFloor) arrived = true;

            if (arrived)
            {
                elevator.Position = elevator.TargetFloor;
                elevator.Direction = Direction.None;

                if (elevator.HelpRequested)
                {
                    elevator.HelpRequested = false;
                    elevator.ChangeState(elevator.StateHelp, "HELP CALLED: stopped at floor " + elevator.TargetFloor);
                }
                else
                {
                    elevator.ChangeState(elevator.StateDoorsOpening, "Arrived at floor " + elevator.TargetFloor);
                }
            }
        }

        public override void OpenDoor()
        {
            elevator.Notify("Open door ignored: elevator is moving");
        }
    }
}
