using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    public class IdleState : ElevatorState
    {
        public IdleState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get { return "Idle"; }
        }

        public override void Tick()
        {
            if (elevator.Stops.Count == 0) return;      

            int next = elevator.Stops[0];              
            elevator.Stops.RemoveAt(0);
            elevator.TargetFloor = next;

            if (next == elevator.CurrentFloor)
            {
                // already on that floor: just open the doors
                elevator.ChangeState(elevator.StateDoorsOpening, "Doors opening at floor " + next);
            }
            else
            {
                if (next > elevator.CurrentFloor)
                    elevator.Direction = Direction.Up;
                else
                    elevator.Direction = Direction.Down;
                elevator.ChangeState(elevator.StateMoving, "Moving " + elevator.Direction + " to floor " + next);
            }
        }

        public override void OpenDoor()
        {
            elevator.ChangeState(elevator.StateDoorsOpening, "Door opened manually");
        }
    }
}
