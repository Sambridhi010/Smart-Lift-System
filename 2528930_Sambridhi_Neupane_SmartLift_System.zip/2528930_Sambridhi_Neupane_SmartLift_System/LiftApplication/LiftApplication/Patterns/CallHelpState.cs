using LiftApplication.Models;

namespace LiftApplication.Patterns
{
    
    public class CallHelpState : ElevatorState
    {
        public CallHelpState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get { return "HELP CALLED"; }
        }

        public override string DoorText
        {
            get { return elevator.DoorTextByOpenness; }
        }

        public override void Tick()
        {
            elevator.OpenDoorsOneStep();
        }

        public override void Resume()
        {
            elevator.ChangeState(elevator.StateDoorsClosing, "Help cleared by operator: doors closing");
        }
    }
}
