using System;
using LiftApplication.Models;

namespace LiftApplication.Patterns
{

    public class EmergencyStopState : ElevatorState
    {
        public EmergencyStopState(Elevator elevator) : base(elevator) { }

        public override string Name
        {
            get { return "EMERGENCY STOP"; }
        }

        public override string DoorText
        {
            get { return elevator.DoorTextByOpenness; }
        }

        public override void Tick()
        {
            bool justOpened = elevator.OpenDoorsOneStep();
            if (justOpened)
            {
                elevator.Notify("Emergency exit: doors open at floor " + elevator.CurrentFloor);
            }
        }

        public override void Resume()
        {
            elevator.Direction = Direction.None;

            if (!elevator.AtFloor)
            {
                int target = (int)Math.Round(elevator.Position);
                elevator.TargetFloor = target;
                if (target > elevator.Position)
                    elevator.Direction = Direction.Up;
                else
                    elevator.Direction = Direction.Down;
                elevator.ChangeState(elevator.StateMoving, "Resumed: moving to floor " + target);
            }
            else if (elevator.DoorOpenness > 0)
            {
                elevator.ChangeState(elevator.StateDoorsClosing, "Resumed: doors closing");
            }
            else
            {
                elevator.ChangeState(elevator.StateIdle, "Resumed");
            }
        }
    }
}
