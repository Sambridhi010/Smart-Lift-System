using LiftApplication.Models;

namespace LiftApplication.Patterns
{

    public abstract class ElevatorState
    {
        protected Elevator elevator;     

        public ElevatorState(Elevator elevator)
        {
            this.elevator = elevator;
        }

        public abstract string Name { get; }

        public virtual string DoorText
        {
            get { return "Closed"; }
        }

        public abstract void Tick();

        public virtual void OpenDoor() { }
        public virtual void CloseDoor() { }
        public virtual void Resume() { }
    }
}
