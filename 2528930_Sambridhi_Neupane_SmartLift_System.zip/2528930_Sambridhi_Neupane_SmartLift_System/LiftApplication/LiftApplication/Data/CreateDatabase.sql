-- Run this once in SQL Server Management Studio (New Query > F5).
CREATE DATABASE LiftLog;
GO
USE LiftLog;
GO
CREATE TABLE ElevatorLog (
    LogId        INT IDENTITY(1,1) PRIMARY KEY,
    ElevatorName NVARCHAR(50)  NOT NULL,   
    Operation    NVARCHAR(200) NOT NULL,   
    FloorNumber  INT           NOT NULL,   
    State        NVARCHAR(50)  NOT NULL,  
    Direction    NVARCHAR(20)  NOT NULL,   
    DoorStatus   NVARCHAR(20)  NOT NULL,   
    LoggedAt     DATETIME2(3)  NOT NULL    
);
CREATE INDEX IX_ElevatorLog_LoggedAt ON ElevatorLog (LoggedAt);
GO
