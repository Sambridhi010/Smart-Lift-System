﻿namespace LiftApplication.Forms
{
    partial class LogForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblLogTitle = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.dgvLog = new System.Windows.Forms.DataGridView();
            this.lblLogStatus = new System.Windows.Forms.Label();
            this.bwLoadLog = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogTitle
            // 
            this.lblLogTitle.Location = new System.Drawing.Point(15, 14);
            this.lblLogTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogTitle.ForeColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblLogTitle.Text = "Elevator Log";
            this.lblLogTitle.AutoSize = true;
            this.lblLogTitle.Name = "lblLogTitle";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(765, 12);
            this.btnRefresh.Size = new System.Drawing.Size(110, 32);
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.FlatAppearance.BorderSize = 0;
            this.btnRefresh.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.TabIndex = 0;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // dgvLog
            // 
            this.dgvLog.Location = new System.Drawing.Point(0, 56);
            this.dgvLog.Size = new System.Drawing.Size(890, 420);
            this.dgvLog.AllowUserToAddRows = false;
            this.dgvLog.AllowUserToDeleteRows = false;
            this.dgvLog.ReadOnly = true;
            this.dgvLog.RowHeadersVisible = false;
            this.dgvLog.BackgroundColor = System.Drawing.Color.White;
            this.dgvLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLog.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLog.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.dgvLog.Name = "dgvLog";
            this.dgvLog.TabIndex = 1;
            // 
            // lblLogStatus
            // 
            this.lblLogStatus.Location = new System.Drawing.Point(15, 488);
            this.lblLogStatus.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogStatus.ForeColor = System.Drawing.Color.FromArgb(22, 40, 77);
            this.lblLogStatus.Text = "Loading log...";
            this.lblLogStatus.AutoSize = true;
            this.lblLogStatus.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            this.lblLogStatus.Name = "lblLogStatus";
            // 
            // bwLoadLog
            // 
            this.bwLoadLog.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bwLoadLog_DoWork);
            this.bwLoadLog.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bwLoadLog_RunWorkerCompleted);
            this.Controls.Add(this.lblLogTitle);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvLog);
            this.Controls.Add(this.lblLogStatus);
            // 
            // LogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(244, 247, 252);
            this.ClientSize = new System.Drawing.Size(890, 520);
            this.MinimumSize = new System.Drawing.Size(600, 360);
            this.Name = "LogForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Elevator Log";
            this.Load += new System.EventHandler(this.LogForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLog)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblLogTitle;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DataGridView dgvLog;
        private System.Windows.Forms.Label lblLogStatus;
        private System.ComponentModel.BackgroundWorker bwLoadLog;
    }
}
