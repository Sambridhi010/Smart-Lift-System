using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using LiftApplication.Services;

namespace LiftApplication.Forms
{
    // The log window. It loads the rows in a BackgroundWorker so the window never freezes.
    public partial class LogForm : Form
    {
        private ElevatorLogRepository repository;

        public LogForm() : this(new ElevatorLogRepository()) { }     // needed by the Visual Studio designer

        public LogForm(ElevatorLogRepository repository)
        {
            InitializeComponent();
            this.repository = repository;
        }

        private void LogForm_Load(object sender, EventArgs e)
        {
            StartLoading();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            StartLoading();
        }

        private void StartLoading()
        {
            if (bwLoadLog.IsBusy) return;
            btnRefresh.Enabled = false;
            lblLogStatus.Text = "Loading log...";
            bwLoadLog.RunWorkerAsync();
        }

        // Background thread: read the rows (never touch controls here)
        private void bwLoadLog_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = repository.LoadLog(500);
        }

        // Screen thread: show the rows, or show the error
        private void bwLoadLog_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            btnRefresh.Enabled = true;

            if (e.Error != null)
            {
                lblLogStatus.Text = "Could not load the log.";
                MessageBox.Show(e.Error.Message, "Elevator log", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable table = (DataTable)e.Result;
            dgvLog.DataSource = table;
            lblLogStatus.Text = table.Rows.Count + " entries shown (newest first).";
        }
    }
}
