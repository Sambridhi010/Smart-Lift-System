using System;
using System.Data;
using Microsoft.Data.SqlClient;
using LiftApplication.Models;

namespace LiftApplication.Services
{
   
    public class ElevatorLogRepository
    {
        // To use a different server (for example localhost or .\SQLEXPRESS) change Server= below.
        private string connectionString =
            "Server=(localdb)\\MSSQLLocalDB;Database=LiftLog;Trusted_Connection=True;TrustServerCertificate=True;";

        // Show a friendly error if the database cannot be reached
        public void EnsureAvailable()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                }
            }
            catch (SqlException ex)
            {
                throw new LogDatabaseException(
                    "Could not connect to the LiftLog database on (localdb)\\MSSQLLocalDB.\n\n" +
                    "Run Data\\CreateDatabase.sql in SQL Server Management Studio first.\n\n" + ex.Message, ex);
            }
        }

        // ---- READ: returns the newest rows as a DataTable ----
        public DataTable LoadLog(int maxRows)
        {
            try
            {
                string sql = "SELECT TOP (@max) LogId, LoggedAt AS Time, ElevatorName AS Elevator, Operation, " +
                             "FloorNumber AS Floor, State, Direction, DoorStatus AS Door " +
                             "FROM ElevatorLog ORDER BY LoggedAt DESC, LogId DESC";

                DataTable table = new DataTable("ElevatorLog");
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter(sql, connection))
                {
                    adapter.SelectCommand.Parameters.AddWithValue("@max", maxRows);
                    adapter.Fill(table);        // opens the connection, fills the table, closes it
                }
                return table;
            }
            catch (SqlException ex)
            {
                throw new LogDatabaseException("The log could not be read from the database: " + ex.Message, ex);
            }
        }

        // ---- WRITE: saves one log entry ----
        public void SaveEntry(LogEntry entry)
        {
            try
            {
                // 1. put the entry into a DataTable (the "disconnected" copy)
                DataTable table = new DataTable("ElevatorLog");
                table.Columns.Add("ElevatorName", typeof(string));
                table.Columns.Add("Operation", typeof(string));
                table.Columns.Add("FloorNumber", typeof(int));
                table.Columns.Add("State", typeof(string));
                table.Columns.Add("Direction", typeof(string));
                table.Columns.Add("DoorStatus", typeof(string));
                table.Columns.Add("LoggedAt", typeof(DateTime));
                table.Rows.Add(entry.ElevatorName, entry.Operation, entry.FloorNumber,
                               entry.State, entry.Direction, entry.DoorStatus, entry.LoggedAt);

                // 2. the data adapter sends the new row to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.InsertCommand = CreateInsertCommand(connection);
                    adapter.Update(table);
                }
            }
            catch (SqlException ex)
            {
                throw new LogDatabaseException("The log could not be saved to the database: " + ex.Message, ex);
            }
        }

        // The INSERT command. Each @parameter takes its value from a column of the DataTable.
        private SqlCommand CreateInsertCommand(SqlConnection connection)
        {
            SqlCommand command = new SqlCommand(
                "INSERT INTO ElevatorLog (ElevatorName, Operation, FloorNumber, State, Direction, DoorStatus, LoggedAt) " +
                "VALUES (@name, @operation, @floor, @state, @direction, @door, @at)", connection);

            command.Parameters.Add("@name", SqlDbType.NVarChar, 50, "ElevatorName");
            command.Parameters.Add("@operation", SqlDbType.NVarChar, 200, "Operation");
            command.Parameters.Add("@floor", SqlDbType.Int, 0, "FloorNumber");
            command.Parameters.Add("@state", SqlDbType.NVarChar, 50, "State");
            command.Parameters.Add("@direction", SqlDbType.NVarChar, 20, "Direction");
            command.Parameters.Add("@door", SqlDbType.NVarChar, 20, "DoorStatus");
            command.Parameters.Add("@at", SqlDbType.DateTime2, 0, "LoggedAt");
            command.UpdatedRowSource = UpdateRowSource.None;
            return command;
        }
    }
}
