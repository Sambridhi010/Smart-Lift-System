using System.Collections.Generic;
using LiftApplication.Models;

namespace LiftApplication.Services
{
   
    public class ElevatorDispatcher
    {
        private List<Elevator> elevators;

        public ElevatorDispatcher(List<Elevator> elevators)
        {
            this.elevators = elevators;
        }
        public Elevator HandleOutsideRequest(int floor, out double estimatedSeconds)
        {
            Elevator best = null;
            estimatedSeconds = 0;

            foreach (Elevator elevator in elevators)
            {
                if (!elevator.IsAvailable) continue;        

                if (elevator.IsServing(floor))
                {
                    best = elevator;
                    estimatedSeconds = elevator.EstimateResponseSeconds(floor);
                    break;
                }

                double estimate = elevator.EstimateResponseSeconds(floor);
                if (best == null || estimate < estimatedSeconds)   
                {
                    best = elevator;
                    estimatedSeconds = estimate;
                }
            }

            if (best != null)
            {
                best.AcceptOutsideRequest(floor, estimatedSeconds);
            }
            return best;
        }
    }
}
