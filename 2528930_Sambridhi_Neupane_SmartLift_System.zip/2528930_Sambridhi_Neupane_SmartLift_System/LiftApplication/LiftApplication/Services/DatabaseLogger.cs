using System;
using System.ComponentModel;
using LiftApplication.Models;
using LiftApplication.Patterns;

namespace LiftApplication.Services
{

    public class DatabaseLogger : IElevatorObserver
    {
        private ElevatorLogRepository repository;

        public event Action<string> SaveFailed;

        public DatabaseLogger(ElevatorLogRepository repository)
        {
            this.repository = repository;
        }

        public void Update(Elevator elevator, string message)
        {
            if (message == "") return;      
            LogEntry entry = new LogEntry();
            entry.ElevatorName = elevator.Name;
            entry.Operation = message;
            entry.FloorNumber = elevator.CurrentFloor;
            entry.State = elevator.StatusText;
            entry.Direction = elevator.Direction.ToString();
            entry.DoorStatus = elevator.DoorText;
            entry.LoggedAt = DateTime.Now;

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += Worker_DoWork;
            worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            worker.RunWorkerAsync(entry);
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            LogEntry entry = (LogEntry)e.Argument;
            repository.SaveEntry(entry);
        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null && SaveFailed != null)
            {
                SaveFailed(e.Error.Message);
            }
        }
    }
}
