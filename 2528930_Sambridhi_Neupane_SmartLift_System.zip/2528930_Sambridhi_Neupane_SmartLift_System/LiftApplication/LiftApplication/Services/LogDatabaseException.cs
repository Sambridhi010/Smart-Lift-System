using System;

namespace LiftApplication.Services
{
    // Our own exception type for database problems. Its message is safe to show to the user.
    public class LogDatabaseException : Exception
    {
        public LogDatabaseException(string message, Exception inner) : base(message, inner) { }
    }
}
